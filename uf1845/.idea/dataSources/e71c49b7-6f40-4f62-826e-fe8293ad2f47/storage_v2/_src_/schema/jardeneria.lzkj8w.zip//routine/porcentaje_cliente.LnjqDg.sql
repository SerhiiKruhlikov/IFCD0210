create
    definer = workuser@`%` procedure porcentaje_cliente(IN v_codigo_cliente int)
begin
	select sum(dp.cantidad * dp.precio_unidad)
	into @total_global
	from detalle_pedido dp;

	select sum(dp.cantidad * dp.precio_unidad) into @total_cliente
	from pedido p
	join detalle_pedido dp 
	on dp.codigo_pedido = p.codigo_pedido
	where p.codigo_cliente = v_codigo_cliente;
	
	select (@total_client / @total_global)  * 100;
	
end;

