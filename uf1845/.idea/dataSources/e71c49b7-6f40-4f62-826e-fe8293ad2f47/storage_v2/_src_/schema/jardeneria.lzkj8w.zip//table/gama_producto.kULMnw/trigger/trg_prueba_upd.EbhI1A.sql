create definer = workuser@`%` trigger trg_prueba_upd
    before update
    on gama_producto
    for each row
begin
	declare t_descripcion_html varchar(50) default "<h1>producto</h1>";
	if new.descripcion_texto = old.descripcion_texto then
		set new.descripcion_html = t_descripcion_html;
	end if;

	insert into log(texto) values(concat_ws("", "Gama Producto Actualizado:", new.gama));

end;

