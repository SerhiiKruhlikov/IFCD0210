create
    definer = workuser@`%` procedure total_pedido(IN v_codigo_pedido int)
begin
	select sum(dp.cantidad * dp.precio_unidad) as total
	from detalle_pedido dp 
	where dp.codigo_pedido = v_codigo_pedido;

end;

