create
    definer = workuser@`%` procedure rentabilidad_pedido(IN v_pedido int)
begin
	
--	declare hay_pedido = -1;
	select count(*) into @total
	from pedido p
	where p.codigo_pedido = v_pedido;
	
	if @total > 0 then	
		select
			sum(dp.cantidad * dp.precio_unidad) - sum(dp.cantidad * p.precio_proveedor) as rentabilidad
		from
			detalle_pedido dp 
		join
			producto p 
		on
			p.codigo_producto = dp.codigo_producto 
		where
			dp.codigo_pedido = v_pedido;
	else
		select "El pedido no existe";
	end if;
	
end;

