create definer = workuser@`%` trigger trg_primero
    before insert
    on gama_producto
    for each row
begin
	if new.descripcion_texto is null then
		set new.descripcion_texto = "Sin descripcion";
	end if;

end;

