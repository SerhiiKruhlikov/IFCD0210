create
    definer = workuser@`%` procedure comprueba_nulos(IN cadena1 varchar(50), IN cadena2 varchar(50))
begin

	declare resultado varchar(100);
	declare v1 varchar(50);
	declare v2 varchar(50);
	
--	set resultado = ifnull(concat(cadena1, cadena2), "Las cadenas son nulas");
	set v1 = ifnull(cadena1, "");
	set v2 = ifnull(cadena2, "");
	
--	select resultado;
	set resultado = concat(v1, v2);
	select resultado;

end;

