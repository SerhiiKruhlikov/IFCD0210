create
    definer = workuser@`%` procedure comparador(IN primero int, IN segundo int)
begin
	declare relacion varchar(50);
	
	if primero > segundo then
		set relacion = "ES MAYOR QUE";
	elseif primero = segundo then
		set relacion = "ES IGUAL QUE";
	else
		set relacion = "ES MENOR QUE";
	end if;
	
	select CONCAT_WS(" ", primero, relacion, segundo) as resulto;
	
end;

