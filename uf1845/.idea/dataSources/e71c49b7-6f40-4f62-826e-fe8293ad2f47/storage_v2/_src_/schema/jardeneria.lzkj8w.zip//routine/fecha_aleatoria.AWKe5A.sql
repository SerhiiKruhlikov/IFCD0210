create
    definer = workuser@`%` function fecha_aleatoria() returns date
begin
	return date_add(currdate(), interval floor(rand() * 30) day);

end;

