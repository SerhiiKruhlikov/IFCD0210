create definer = workuser@`%` view resumen_pedidos as
select `c`.`nombre_cliente`   AS `nombre_cliente`,
       `p`.`codigo_pedido`    AS `codigo_pedido`,
       `dp`.`cantidad`        AS `cantidad`,
       `dp`.`precio_unidad`   AS `precio_unidad`,
       `dp`.`codigo_producto` AS `codigo_producto`,
       `prod`.`gama`          AS `gama`
from (((`jardeneria`.`pedido` `p` join `jardeneria`.`cliente` `c`
        on ((`p`.`codigo_cliente` = `c`.`codigo_cliente`))) join `jardeneria`.`detalle_pedido` `dp`
       on ((`p`.`codigo_pedido` = `dp`.`codigo_pedido`))) join `jardeneria`.`producto` `prod`
      on ((`dp`.`codigo_producto` = `prod`.`codigo_producto`)));

