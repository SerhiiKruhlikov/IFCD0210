create
    definer = workuser@`%` function fn_total_pedidos_cliente(v_cod_cliente int) returns int deterministic
begin
	declare v_total int;

	
	select count(*) into v_total
	from pedido p
	where p.codigo_cliente = v_cod_cliente;
	
	return v_total;

end;

