create
    definer = workuser@`%` procedure importe_medio(IN v_cliente int)
begin
	select avg(dp.cantidad * dp.precio_unidad) as promedio
	from pedido p
	join detalle_pedido dp 
	on p.codigo_pedido = dp.codigo_pedido 
	where p.codigo_cliente = v_cliente;

end;

