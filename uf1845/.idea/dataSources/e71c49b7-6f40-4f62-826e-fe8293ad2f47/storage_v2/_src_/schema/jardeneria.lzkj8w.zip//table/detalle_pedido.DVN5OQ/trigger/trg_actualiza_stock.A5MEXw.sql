create definer = workuser@`%` trigger trg_actualiza_stock
    after insert
    on detalle_pedido
    for each row
begin
	update producto
	set cantidad_en_stock = cantidad_en_stock - new.cantidad
	where cantidad_en_stock = new.codigo_producto;

end;

