create
    definer = workuser@`%` procedure total_cliente(IN v_codigo_cliente int)
begin
	select c.nombre_cliente, sum(dp.cantidad * dp.precio_unidad) as total
	from cliente c
	join pedido p 
	on c.codigo_cliente = p.codigo_cliente 
	join detalle_pedido dp 
	on dp.codigo_pedido = p.codigo_pedido
	where c.codigo_cliente = v_codigo_cliente
	group by c.nombre_cliente;

end;

