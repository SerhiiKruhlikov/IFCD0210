create
    definer = workuser@`%` procedure resumen_pedido(IN v_codigo_pedido int)
begin
	select * from pedido p 
	join cliente c
	on p.codigo_cliente = c.codigo_cliente 
	join detalle_pedido dp 
	on p.codigo_pedido = dp.codigo_pedido 
	join producto prod
	on dp.codigo_producto = prod.codigo_producto 
	where p.codigo_pedido = v_codigo_pedido;
end;

