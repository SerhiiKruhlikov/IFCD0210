create
    definer = workuser@`%` procedure resumen_pedido_2(IN v_codigo_pedido int)
begin
	select * from resumen_pedidos
	where codigo_pedido = v_codigo_pedido;
end;

