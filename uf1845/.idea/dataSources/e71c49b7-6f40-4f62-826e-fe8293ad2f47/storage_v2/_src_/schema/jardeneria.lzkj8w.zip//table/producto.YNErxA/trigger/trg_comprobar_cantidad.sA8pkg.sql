create definer = workuser@`%` trigger trg_comprobar_cantidad
    before update
    on producto
    for each row
begin
	if new.cantidad_en_stock > old.cantidad_en_stock then
		signal sqlstate '45000'
		set message_text = "No se puede sacar más de lo que hay.";
	else
		set new.cantidad_en_stock = old.cantidad_en_stock - new.cantidad_en_stock;
	end if;

end;

